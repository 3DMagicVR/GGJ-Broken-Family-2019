﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WinLose : MonoBehaviour
{
    public GameManager gM;
    public Animator anm;
    public Movement move;

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Enemy"))
        {
            anm.SetTrigger("Hit");
            gM.timer.StartRoutine(2);
            anm.SetFloat("Time", gM.timer.time);

            if (gM.timer.time < 0.1f)
            {
                move.enabled = false;
                move.rgb.velocity = Vector2.zero;
                Debug.Log("Game Over Dude!");
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("WinCircle"))
            Debug.Log("Ganaste!");
    }
}
