﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{
    public float time;
    public Text timerUI;
    public Text penaltyTxt;
    public Animator penaltyAnm;
    public GameManager gM;

    [HideInInspector] public bool trapped;

    private float penaltyTime = 1;
    private float second;

    private void Awake()
    {
        gM.timer = this;
    }

    private void Update()
    {
        second += Time.deltaTime;

        if (second >= penaltyTime)
        {
            second = Mathf.Clamp(second - 1, 0, 100);
            time = Mathf.Clamp(time - 1, 0, 10000);
            penaltyTime = trapped ? Mathf.Clamp(penaltyTime * 0.9f, 0.05f, 1) : 1;

            timerUI.text = time.ToString("F0");
        }
    }

    public void StartRoutine(int i) { StartCoroutine(SlowTime(i)); }

    public IEnumerator SlowTime(int i)
    {
        penaltyTxt.text = "-" + i.ToString();
        penaltyAnm.SetTrigger("TimeReduce");
        time -= i;
        timerUI.text = time.ToString("F0");
        Time.timeScale = 0.4f;
        while (Time.timeScale < 1)
        {
            Time.timeScale = Mathf.Clamp(Time.timeScale + Time.deltaTime, 0, 1);
            yield return new WaitForEndOfFrame();
        }
        Time.timeScale = 1;
    }
}
