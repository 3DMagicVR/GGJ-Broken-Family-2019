﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ReduceTime : MonoBehaviour
{
    public GameManager gM;

    private void OnTriggerEnter2D(Collider2D c)
    {
        PowerUp pU = c.GetComponentInParent<PowerUp>();
        if(c.CompareTag("Player") && !pU.timeImmunity)
        {
            int i = Random.Range(2, 5);
            gM.timer.StartRoutine(i);
            Destroy(gameObject);
        }
    }
}
