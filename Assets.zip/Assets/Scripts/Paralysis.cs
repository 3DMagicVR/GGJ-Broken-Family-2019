﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Paralysis : MonoBehaviour
{
    public SpriteRenderer rnd;
    public Animator anm;

    private bool running;
    
    private void OnTriggerEnter2D(Collider2D c)
    {
        if (c.CompareTag("Paralysis") && !running)
        {
            anm.SetTrigger("Activate");
            running = true;
            StartCoroutine(Paralize(c.gameObject));
        }
    }

    IEnumerator Paralize(GameObject g)
    {
        Rigidbody2D rgb = g.GetComponentInParent<Rigidbody2D>();
        rgb.simulated = false;

        SpriteRenderer rndPlayer = g.GetComponentInParent<SpriteRenderer>();
        Color playerC = rndPlayer.color;
        rndPlayer.color = Color.red;

        int waitTime = Random.Range(3, 6);
        Color c = rnd.color;
        for (int i = 0; i < 3; i++)
        {
            yield return new WaitForSeconds(waitTime / 3 - (Time.deltaTime * 3));
            c.a = 0;
            rnd.color = c;
            yield return new WaitForSeconds(Time.deltaTime * 3);
            c.a = 1;
            rnd.color = c;
        }

        rndPlayer.color = playerC;
        rgb.simulated = true;
        Destroy(gameObject);
    }
}
