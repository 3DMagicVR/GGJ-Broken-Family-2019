﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Confuse : MonoBehaviour
{
    private Movement m;

    private void OnTriggerEnter2D(Collider2D o)
    {
        if (o.CompareTag("Player"))
        {
            m = o.GetComponentInParent<Movement>();
            if (!m.confused)
            {
                m.confused = true;
                StartCoroutine(Restore());
            }
        }
    }

    IEnumerator Restore()
    {
        yield return new WaitForSeconds(Random.Range(4,7));
        m.confused = false;
    }
}
