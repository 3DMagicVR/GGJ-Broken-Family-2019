﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PowerUp : MonoBehaviour
{
    public Collider2D paraCol;
    public Collider2D enemyCol;
    public Sprite[] abilities;
    public Image[] abilityIcons;

    [HideInInspector] public bool timeImmunity;
    [HideInInspector] public bool slowImmunity;
    [HideInInspector] public bool paralysisImmunity;

    private bool[] itemActive = new bool[3];
    private int[] itemEffect = new int[3];
    private int iconEffect;
    private float duration;
    private bool usingPower;

    private void OnTriggerEnter2D(Collider2D o)
    {
        if (o.CompareTag("PowerUp"))
        {
            Destroy(o.gameObject);
            int itemSelected = 0;
            bool checkingItems = true;
            while (checkingItems)
            {
                checkingItems = itemActive[itemSelected];
                if (checkingItems)
                {
                    itemSelected++;
                    if (itemSelected >= 3)
                        return;
                }
            }
            itemActive[itemSelected] = true;

            int effect = Random.Range(0, 7);
            effect = effect > 6 ? 6 : effect;
            itemEffect[itemSelected] = effect;

            iconEffect = Mathf.FloorToInt(effect / 2);
            abilityIcons[itemSelected].sprite = abilities[iconEffect];
        }
    }

    private void Update()
    {
        if ((Input.GetButtonDown("Fire1") && itemActive[0] || Input.GetButtonDown("Fire2") && itemActive[1] || Input.GetButtonDown("Fire3") && itemActive[2]) && !usingPower)
        {
            usingPower = true;
            int itemUsed = Input.GetButtonDown("Fire1") ? 0 : 1;
            itemUsed = Input.GetButtonDown("Fire3") ? 2 : itemUsed;
            abilityIcons[itemUsed].sprite = abilities[4];
            itemActive[itemUsed] = false;

            for (int i = 0; i < 3; i++)
            {
                Color c = abilityIcons[i].color;
                c.a = 0.3f;
                abilityIcons[i].color = c;
            }

            if (itemEffect[itemUsed] == 6)
            {
                paraCol.enabled = false;
                enemyCol.enabled = false;
            }

            if (itemEffect[itemUsed] == 0 || itemEffect[itemUsed] == 1)
                paraCol.enabled = false;

            if (itemEffect[itemUsed] == 2 || itemEffect[itemUsed] == 3)
                timeImmunity = true;

            if (itemEffect[itemUsed] == 4 || itemEffect[itemUsed] == 5)
                slowImmunity = true;

            StartCoroutine(EndPowerUp());
        }
    }

    IEnumerator EndPowerUp()
    {
        yield return new WaitForSeconds(4);

        paraCol.enabled = true;
        enemyCol.enabled = true;
        timeImmunity = false;
        slowImmunity = false;
        paralysisImmunity = false;
        usingPower = false;

        for (int i = 0; i < 3; i++)
        {
            Color c = abilityIcons[i].color;
            c.a = 1f;
            abilityIcons[i].color = c;
        }
    }
}
