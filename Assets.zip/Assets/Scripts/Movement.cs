﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class Movement : MonoBehaviour
{
    public float speed;
    public Rigidbody2D rgb;
    public float dragSpeed;
    public float dragLimit;
    public LayerMask moveLayer;
    public PowerUp pU;
    public GameManager gM;

    [HideInInspector] public float speedModifier;
    [HideInInspector] public bool confused;
    [HideInInspector] public Vector2 vSpeed;

    private bool xAxis;
    private bool yAxis;
    private bool lastPressedH;
    private bool[] moveCheck = new bool[4];

    void Update()
    {
        gM.player = transform.position;

        xAxis = Input.GetButton("Horizontal");
        yAxis = Input.GetButton("Vertical");

        if (xAxis && !yAxis || yAxis && Input.GetButtonDown("Horizontal"))
            lastPressedH = true;
        if (yAxis && !xAxis || xAxis && Input.GetButtonDown("Vertical"))
            lastPressedH = false;
    }

    private void FixedUpdate()
    {
        vSpeed.x = lastPressedH ? Input.GetAxisRaw("Horizontal") * speed : 0;
        vSpeed.y = !lastPressedH ? Input.GetAxisRaw("Vertical") * speed : 0;
        vSpeed = confused ? vSpeed * -1 : vSpeed;

        rgb.velocity = vSpeed;
    }

    private void OnTriggerStay2D(Collider2D c)
    {
        if (c.CompareTag("Dragger") && !pU.slowImmunity)
            rgb.drag = Mathf.Clamp(rgb.drag + dragSpeed, 0, dragLimit);
    }

    private void OnTriggerExit2D(Collider2D o)
    {
        if (o.CompareTag("Dragger"))
            rgb.drag = 0;
    }

    private void OnCollisionEnter2D(Collision2D c)
    {
        if (c.transform.CompareTag("Enemy"))
        {
            moveCheck[0] = Physics2D.Linecast(transform.position, new Vector2(transform.position.x, transform.position.y + 1.5f), moveLayer);
            moveCheck[1] = Physics2D.Linecast(transform.position, new Vector2(transform.position.x, transform.position.y - 1.5f), moveLayer);
            moveCheck[2] = Physics2D.Linecast(transform.position, new Vector2(transform.position.x + 1.5f, transform.position.y), moveLayer);
            moveCheck[3] = Physics2D.Linecast(transform.position, new Vector2(transform.position.x - 1.5f, transform.position.y), moveLayer);

            int i = 0;
            foreach (bool b in moveCheck)
            {
                i = b ? i + 1 : 0;
                if (i >= 4)
                    gM.timer.trapped = true;
            }
        }
    }
}

