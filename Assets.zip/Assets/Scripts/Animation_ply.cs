﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Animation_ply : MonoBehaviour
{
    public Movement move;
    public Animator anm;

    private bool facingLeft;

    private void Update()
    {
        CheckIfFlip();

        if (move.vSpeed.x != 0)
        {
            anm.SetFloat("xAxis", 1);
            anm.SetFloat("yAxis", 0);
        }
        if (move.vSpeed.y != 0)
        {
            anm.SetFloat("xAxis", 0);
            anm.SetFloat("yAxis", move.vSpeed.y);
        }

        if (move.rgb.velocity == Vector2.zero)
            anm.SetBool("Walking", false);
        else if (move.rgb.velocity != Vector2.zero)
            anm.SetBool("Walking", true);
    }

    private void CheckIfFlip()
    {
        if ((move.rgb.velocity.x > 0 || move.rgb.velocity.y != 0) && facingLeft )
            FlipXAxis();
        else if (move.rgb.velocity.x < 0 && !facingLeft)
            FlipXAxis();
    }

    public void FlipXAxis()
    {
        facingLeft = !facingLeft;
        Vector3 vTemp = transform.localScale;
        vTemp.x *= -1;
        transform.localScale = vTemp;
    }
}
