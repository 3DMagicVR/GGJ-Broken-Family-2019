﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Game Manager", menuName = "Game Manager")]
public class GameManager : ScriptableObject
{
    public Vector2 player;
    public Timer timer;
}
