﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class AI_enemy : MonoBehaviour
{
    public GameManager gM;
    public float speed;

    private Vector2 player;
    private Rigidbody2D rgb;
    private Vector2 startPos;

    private void Start()
    {
        rgb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        player = gM.player;
        transform.position = Vector2.MoveTowards(transform.position, player, Time.deltaTime * speed);
    }
}